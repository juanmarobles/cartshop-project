import { useState } from "react";

const initialState = {
    cart: [],
}

const useInitialState = () => {

    const [state, setState] = useState(initialState);

    const AddtoCart = (payload) => {
        setState({
            ...state,
            cart: [...state.cart, payload]
        })
    }

    const removeFromCart = (indexValue) => {
        setState({
          ...state,
          cart: state.cart.filter((_, index) => index !== indexValue),
        })
      }

    return {
        state,
        AddtoCart,
        removeFromCart
    }
}

export default useInitialState;