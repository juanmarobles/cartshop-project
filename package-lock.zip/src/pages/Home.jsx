import React from 'react';
import ProductList from '../containers/ProductList';

const Home = () => {
	return (
		<>
			<ProductList />
		</>
        
	);
}


export default Home;