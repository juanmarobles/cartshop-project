import React from 'react'

const NotFound = () => {
    return (
        <div>
            <h1>No encontrado, error 404.</h1>
            <img src="https://dinahosting.com/blog/cont/uploads/2021/03/error-404-1170x658.jpg" alt="error-404" />
        </div>
    );
}

export default NotFound;